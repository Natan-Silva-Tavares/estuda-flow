import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';
// Estas três referências ligam o componente principal à inicialização do Angular.
bootstrapApplication(AppComponent, appConfig).catch((error: unknown) => console.error(error));
// A inicialização mostra qualquer falha cedo no console do navegador.

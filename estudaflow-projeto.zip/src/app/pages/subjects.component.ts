import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
// A tela de matérias cadastra, lista, atualiza e remove disciplinas.
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { ApiService } from '../core/api.service';
import { Subject, SubjectDraft } from '../core/models';
// O formulário e a coleção usam os tipos compartilhados com a API.
@Component({
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  selector: 'app-subjects',
  standalone: true,
  imports: [CommonModule, FormsModule, MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule],
  templateUrl: './subjects.component.html',
  styleUrl: './subjects.component.scss'
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
})
export class SubjectsComponent implements OnInit {
  private readonly api = inject(ApiService);
  private readonly cdr = inject(ChangeDetectorRef);
  subjects: Subject[] = [];
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  editingId: number | null = null;
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  // O estado do formulário acompanha inclusão, edição e mensagens de falha.
  draft: SubjectDraft = { name: '', color: '#7569dd' };
  message = '';
  messageSuccess = false;
  readonly colors = ['#7569dd', '#e99b69', '#55ac8c', '#5596d5', '#d86f8d', '#8c9c54'];
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  // As cores oferecem uma forma rápida de reconhecer cada matéria.
  ngOnInit(): void { this.load(); }
  load(): void {
    this.api.getSubjects().subscribe({
      next: (items) => { this.subjects = items; this.cdr.markForCheck(); },
      error: () => { this.message = 'A API não está disponível. Rode npm start para ligar o app.'; this.messageSuccess = false; this.cdr.markForCheck(); }
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
    });
  }
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  // A lista sempre é atualizada a partir da resposta persistida no servidor.
  edit(subject: Subject): void { this.editingId = subject.id; this.draft = { name: subject.name, color: subject.color }; this.message = ''; this.messageSuccess = false; }
  cancel(): void { this.editingId = null; this.draft = { name: '', color: '#7569dd' }; this.message = ''; this.messageSuccess = false; }
  // Cancelar descarta alterações locais sem alterar o registro salvo.
  save(): void {
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
    const name = this.draft.name.trim();
    if (!name) { this.message = 'Digite o nome da matéria.'; return; }
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
    const editingId = this.editingId;
    const request = editingId !== null ? this.api.updateSubject(editingId, { ...this.draft, name }) : this.api.createSubject({ ...this.draft, name });
    request.subscribe({
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
      next: () => { this.cancel(); this.message = editingId !== null ? 'Matéria atualizada com sucesso.' : 'Matéria salva com sucesso.'; this.messageSuccess = true; this.cdr.markForCheck(); this.load(); },
      error: () => { this.message = 'A API não respondeu. Confira se npm start está em execução.'; this.messageSuccess = false; this.cdr.markForCheck(); }
    });
  }
  // O mesmo botão salva um cadastro novo ou as mudanças de uma edição.
  remove(subject: Subject): void {
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
    if (!window.confirm(`Excluir a matéria “${subject.name}”?`)) return;
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
    this.api.deleteSubject(subject.id).subscribe({
      next: () => { this.load(); },
      error: () => { this.message = 'Não foi possível excluir esta matéria.'; this.messageSuccess = false; this.cdr.markForCheck(); }
    });
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  }
  // A confirmação protege contra remoções acidentais antes de chamar a API.
}

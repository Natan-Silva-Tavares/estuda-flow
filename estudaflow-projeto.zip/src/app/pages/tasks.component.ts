import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
// A tela de tarefas oferece os quatro passos: criar, consultar, editar e excluir.
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { ApiService } from '../core/api.service';
import { Priority, Subject, Task, TaskDraft, TaskStatus } from '../core/models';
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
// Os formulários compartilham os mesmos estados que o servidor armazena.
@Component({
  selector: 'app-tasks',
  standalone: true,
  imports: [CommonModule, FormsModule, MatButtonModule, MatFormFieldModule, MatIconModule, MatInputModule, MatSelectModule],
  templateUrl: './tasks.component.html',
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  styleUrl: './tasks.component.scss'
})
export class TasksComponent implements OnInit {
  private readonly api = inject(ApiService);
  private readonly cdr = inject(ChangeDetectorRef);
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  tasks: Task[] = [];
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  subjects: Subject[] = [];
  editingId: number | null = null;
  // A lista e o formulário ficam no mesmo contexto para edição rápida.
  draft: TaskDraft = this.emptyDraft();
  message = '';
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  readonly priorities: Priority[] = ['Alta', 'Média', 'Baixa'];
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  readonly statuses: TaskStatus[] = ['Pendente', 'Em andamento', 'Concluída'];
  // As opções fechadas garantem valores consistentes entre front e banco.
  ngOnInit(): void {
    this.load();
    this.api.getSubjects().subscribe({ next: (items) => { this.subjects = items; this.cdr.markForCheck(); } });
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  }
  private emptyDraft(): TaskDraft { return { title: '', description: '', subject_id: null, due_date: new Date().toISOString().slice(0, 10), priority: 'Média', status: 'Pendente' }; }
  load(): void {
    this.api.getTasks().subscribe({
      next: (items) => { this.tasks = items; this.cdr.markForCheck(); },
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
      error: () => { this.message = 'Não foi possível carregar as tarefas. Confira se a API está ligada.'; this.cdr.markForCheck(); }
    });
  }
  // A lista vem do banco e cada tarefa pode ser relacionada a uma matéria.
  edit(task: Task): void { this.editingId = task.id; this.draft = { title: task.title, description: task.description, subject_id: task.subject_id, due_date: task.due_date, priority: task.priority, status: task.status }; this.message = ''; window.scrollTo({ top: 0, behavior: 'smooth' }); }
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  cancel(): void { this.editingId = null; this.draft = this.emptyDraft(); this.message = ''; }
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  // A edição reaproveita a forma de cadastro e permite cancelar sem persistir.
  save(): void {
    const title = this.draft.title.trim();
    if (!title) { this.message = 'Escreva um título para a tarefa.'; return; }
    const payload: TaskDraft = { ...this.draft, title, description: this.draft.description.trim() };
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
    const request = this.editingId ? this.api.updateTask(this.editingId, payload) : this.api.createTask(payload);
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
    request.subscribe({
      next: () => { this.cancel(); this.message = 'Tarefa salva com sucesso.'; this.cdr.markForCheck(); this.load(); },
      error: () => { this.message = 'Não foi possível salvar a tarefa. Tente novamente.'; this.cdr.markForCheck(); }
    });
  }
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  // O envio limpa espaços e escolhe criar ou atualizar conforme o estado atual.
  remove(task: Task): void {
    if (!window.confirm(`Excluir a tarefa “${task.title}”?`)) return;
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
    this.api.deleteTask(task.id).subscribe({
      next: () => { if (this.editingId === task.id) this.cancel(); this.load(); },
      error: () => { this.message = 'Não foi possível excluir esta tarefa.'; this.cdr.markForCheck(); }
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
    });
  }
  // A confirmação evita apagar uma tarefa por um clique sem querer.
}

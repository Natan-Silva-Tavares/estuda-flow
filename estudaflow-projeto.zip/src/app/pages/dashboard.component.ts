import { ChangeDetectorRef, Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { ApiService } from '../core/api.service';
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
// A visão geral reúne os registros e converte os dados em pequenos resumos.
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, MatIconModule],
  templateUrl: './dashboard.component.html',
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  styleUrl: './dashboard.component.scss'
})
// A tela usa o serviço compartilhado e os links apontam para as rotas de gestão.
export class DashboardComponent implements OnInit {
  private readonly api = inject(ApiService);
  private readonly cdr = inject(ChangeDetectorRef);
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  tasks: import('../core/models').Task[] = [];
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  subjects: import('../core/models').Subject[] = [];
  loading = true;
  // A tela apresenta contagens úteis enquanto carrega os dados da API.
  get pendingCount(): number { return this.tasks.filter((task) => task.status !== 'Concluída').length; }
  get completedCount(): number { return this.tasks.filter((task) => task.status === 'Concluída').length; }
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
  get completionRate(): number { return this.tasks.length ? Math.round(this.completedCount / this.tasks.length * 100) : 0; }
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  // Os valores calculados acompanham a lista sem guardar cópias desatualizadas.
  ngOnInit(): void {
    this.api.getTasks().subscribe({
      next: (items) => { this.tasks = items; this.loading = false; this.cdr.markForCheck(); },
      error: () => { this.loading = false; this.cdr.markForCheck(); }
// Este grupo atualiza os dados da tela e avisa o Angular que deve redesenhar.
    });
    this.api.getSubjects().subscribe({ next: (items) => { this.subjects = items; this.cdr.markForCheck(); } });
  }
  // Falhas de rede encerram o indicador e ainda permitem navegar para outras telas.
}
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.

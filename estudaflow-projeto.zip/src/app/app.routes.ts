import { Routes } from '@angular/router';
import { DashboardComponent } from './pages/dashboard.component';
import { SubjectsComponent } from './pages/subjects.component';
import { TasksComponent } from './pages/tasks.component';
// Cada rota escolhe uma tela sem recarregar o documento inteiro.
export const routes: Routes = [
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  { path: '', component: DashboardComponent, title: 'Visão geral | EstudaFlow' },
  { path: 'tarefas', component: TasksComponent, title: 'Tarefas | EstudaFlow' },
  { path: 'materias', component: SubjectsComponent, title: 'Matérias | EstudaFlow' },
  { path: '**', redirectTo: '' }
];
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
// O caminho final devolve endereços desconhecidos para a página inicial.

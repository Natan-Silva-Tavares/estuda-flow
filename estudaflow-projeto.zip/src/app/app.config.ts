import { ApplicationConfig } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideRouter } from '@angular/router';
import { routes } from './app.routes';
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
// Os provedores deixam rede, animações e navegação disponíveis na aplicação toda.
export const appConfig: ApplicationConfig = {
  providers: [provideHttpClient(), provideAnimationsAsync(), provideRouter(routes)]
};
// A configuração central evita repetir serviços globais em cada tela.

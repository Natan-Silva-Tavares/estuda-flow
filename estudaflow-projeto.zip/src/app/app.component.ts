import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
// O componente raiz cuida do menu e reserva o espaço de troca das páginas.
@Component({
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, MatButtonModule, MatIconModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  changeDetection: ChangeDetectionStrategy.OnPush
})
// O modo standalone deixa as dependências visíveis no próprio componente.
export class AppComponent { readonly year = new Date().getFullYear(); }
// O ano do rodapé acompanha o calendário automaticamente.

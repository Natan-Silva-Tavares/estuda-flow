export type Priority = 'Alta' | 'Média' | 'Baixa';
export type TaskStatus = 'Pendente' | 'Em andamento' | 'Concluída';
export interface Subject { id: number; name: string; color: string; task_count?: number; }
// Matéria agrupa tarefas e oferece uma cor para identificar a disciplina.
export interface Task { id: number; title: string; description: string; subject_id: number | null; subject_name?: string; subject_color?: string; due_date: string; priority: Priority; status: TaskStatus; }
export type SubjectDraft = Pick<Subject, 'name' | 'color'>;
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
export type TaskDraft = Omit<Task, 'id' | 'subject_name' | 'subject_color'>;
// Os tipos de rascunho contêm só os campos enviados ao servidor.

import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { Subject, SubjectDraft, Task, TaskDraft } from './models';
// Este serviço mantém as telas independentes dos detalhes do endereço da API.
@Injectable({ providedIn: 'root' })
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
export class ApiService {
  private readonly http = inject(HttpClient);
  private readonly endpoint = '/api';
  // O prefixo relativo funciona com o proxy local configurado no Angular.
  getTasks(): Observable<Task[]> { return this.http.get<Task[]>(`${this.endpoint}/tasks`); }
  createTask(draft: TaskDraft): Observable<Task> { return this.http.post<Task>(`${this.endpoint}/tasks`, draft); }
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  updateTask(id: number, draft: TaskDraft): Observable<Task> { return this.http.put<Task>(`${this.endpoint}/tasks/${id}`, draft); }
  deleteTask(id: number): Observable<void> { return this.http.delete<void>(`${this.endpoint}/tasks/${id}`); }
  // As quatro operações deixam o CRUD de tarefas centralizado em um só lugar.
  getSubjects(): Observable<Subject[]> { return this.http.get<Subject[]>(`${this.endpoint}/subjects`); }
  createSubject(draft: SubjectDraft): Observable<Subject> { return this.http.post<Subject>(`${this.endpoint}/subjects`, draft); }
  updateSubject(id: number, draft: SubjectDraft): Observable<Subject> { return this.http.put<Subject>(`${this.endpoint}/subjects/${id}`, draft); }
// Este grupo organiza dados, dependências e ações desta parte do aplicativo.
  deleteSubject(id: number): Observable<void> { return this.http.delete<void>(`${this.endpoint}/subjects/${id}`); }
  // As matérias usam a mesma API e são carregadas nos formulários das tarefas.
}

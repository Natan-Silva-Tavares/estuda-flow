import { createServer } from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
// A API usa módulos nativos do Node e grava os dados em um arquivo SQLite local.
const databasePath = fileURLToPath(new URL('./estudaflow.sqlite', import.meta.url));
const db = new DatabaseSync(databasePath);
// Este grupo prepara ou valida as operações desta parte da API.
db.exec('PRAGMA foreign_keys = ON;');
// Chaves estrangeiras evitam vínculos quebrados entre tarefas e matérias.
db.exec(`CREATE TABLE IF NOT EXISTS subjects (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE COLLATE NOCASE,
  color TEXT NOT NULL DEFAULT '#7569dd'
-- Estas linhas descrevem campos ou relações que a API guarda no SQLite.
);`);
db.exec(`CREATE TABLE IF NOT EXISTS tasks (
  -- Esta tabela conecta cada tarefa a uma matéria sem apagar a tarefa.
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
-- Estas linhas descrevem campos ou relações que a API guarda no SQLite.
  subject_id INTEGER REFERENCES subjects(id) ON DELETE SET NULL,
  due_date TEXT NOT NULL,
  priority TEXT NOT NULL CHECK(priority IN ('Alta', 'Média', 'Baixa')),
  status TEXT NOT NULL CHECK(status IN ('Pendente', 'Em andamento', 'Concluída')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
-- Estas linhas descrevem campos ou relações que a API guarda no SQLite.
);`);
// Excluir matéria deixa a tarefa salva, mas desvincula sua matéria.
const subjectCount = db.prepare('SELECT COUNT(*) AS total FROM subjects').get().total;
if (subjectCount === 0) {
  const addSubject = db.prepare('INSERT INTO subjects (name, color) VALUES (?, ?)');
  addSubject.run('Matemática', '#7569dd');
// Este grupo prepara ou valida as operações desta parte da API.
  addSubject.run('Biologia', '#55ac8c');
  addSubject.run('História', '#e99b69');
  // Os dados iniciais permitem conhecer o painel assim que ele abre.
  const addTask = db.prepare('INSERT INTO tasks (title, description, subject_id, due_date, priority, status) VALUES (?, ?, ?, ?, ?, ?)');
  addTask.run('Revisar funções do 2º grau', 'Resolver os exercícios 1 a 8.', 1, '2026-11-27', 'Alta', 'Pendente');
  addTask.run('Ler sobre ecossistemas', 'Anotar os conceitos principais.', 2, '2026-11-29', 'Média', 'Em andamento');
// Este grupo prepara ou valida as operações desta parte da API.
  addTask.run('Resumo da República Velha', '', 3, '2026-12-02', 'Baixa', 'Concluída');
  // Três registros de exemplo demonstram matéria, prioridade e status.
}
const port = Number(process.env.API_PORT || 3000);
const subjectSelect = `SELECT s.id, s.name, s.color, COUNT(t.id) AS task_count
  FROM subjects s LEFT JOIN tasks t ON t.subject_id = s.id
-- Estas linhas descrevem campos ou relações que a API guarda no SQLite.
  GROUP BY s.id ORDER BY s.name COLLATE NOCASE`;
const subjectById = `SELECT s.id, s.name, s.color, COUNT(t.id) AS task_count
  FROM subjects s LEFT JOIN tasks t ON t.subject_id = s.id WHERE s.id = ? GROUP BY s.id`;
// A consulta de matérias também informa quantas tarefas apontam para cada uma.
const taskSelect = `SELECT t.id, t.title, t.description, t.subject_id, s.name AS subject_name,
  s.color AS subject_color, t.due_date, t.priority, t.status
-- Estas linhas descrevem campos ou relações que a API guarda no SQLite.
  FROM tasks t LEFT JOIN subjects s ON s.id = t.subject_id`;
function sendJson(response, status, value) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify(value));
}
// Este grupo prepara ou valida as operações desta parte da API.
// Todas as respostas da API têm JSON para facilitar o consumo pelo Angular.
async function readJson(request) {
  let raw = '';
  for await (const chunk of request) raw += chunk;
  return raw ? JSON.parse(raw) : {};
}
// Este grupo prepara ou valida as operações desta parte da API.
function fail(status, message) { const error = new Error(message); error.status = status; throw error; }
// A leitura do corpo e o erro tipado mantêm as rotas menores e previsíveis.
function cleanSubject(body) {
  const name = String(body.name || '').trim();
  const color = String(body.color || '#7569dd');
  if (!name || name.length > 60) fail(400, 'Informe um nome de até 60 caracteres.');
// Este grupo prepara ou valida as operações desta parte da API.
  if (!/^#[0-9a-fA-F]{6}$/.test(color)) fail(400, 'A cor deve estar em formato hexadecimal.');
  return { name, color };
}
// As matérias aceitam nomes curtos e cores hexadecimais verificadas.
function cleanTask(body) {
  const title = String(body.title || '').trim();
// Este grupo prepara ou valida as operações desta parte da API.
  const description = String(body.description || '').trim();
  const dueDate = String(body.due_date || '');
  const priority = String(body.priority || 'Média');
  const status = String(body.status || 'Pendente');
  // Campos fixos são conferidos antes de montar qualquer comando SQL.
  const subjectId = body.subject_id == null || body.subject_id === '' ? null : Number(body.subject_id);
// Este grupo prepara ou valida as operações desta parte da API.
  if (!title || title.length > 100) fail(400, 'Informe um título de até 100 caracteres.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) fail(400, 'Informe um prazo válido.');
  if (!['Alta', 'Média', 'Baixa'].includes(priority)) fail(400, 'Prioridade inválida.');
  if (!['Pendente', 'Em andamento', 'Concluída'].includes(status)) fail(400, 'Status inválido.');
  // O vínculo pode ficar vazio, mas se preenchido precisa ser um número.
  if (subjectId !== null && !Number.isInteger(subjectId)) fail(400, 'Matéria inválida.');
// Este grupo prepara ou valida as operações desta parte da API.
  return { title, description, subject_id: subjectId, due_date: dueDate, priority, status };
}
// A validação do servidor protege o banco mesmo que alguém altere a interface.
function exists(table, id) { return Boolean(db.prepare(`SELECT id FROM ${table} WHERE id = ?`).get(id)); }
function routeId(parts) { const id = Number(parts[2]); if (!Number.isInteger(id) || id < 1) fail(400, 'Identificador inválido.'); return id; }
const server = createServer(async (request, response) => {
// Este grupo prepara ou valida as operações desta parte da API.
  response.setHeader('Access-Control-Allow-Origin', '*');
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  response.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  // Os cabeçalhos também permitem testar a API em ferramentas externas.
  if (request.method === 'OPTIONS') { response.writeHead(204); response.end(); return; }
  try {
// Este grupo prepara ou valida as operações desta parte da API.
    const url = new URL(request.url || '/', 'http://localhost');
    const parts = url.pathname.split('/').filter(Boolean);
    const resource = parts[1];
    if (parts[0] !== 'api') fail(404, 'Rota não encontrada.');
    // A URL é separada em recurso e identificador para as rotas CRUD.
    if (request.method === 'GET' && url.pathname === '/api/health') return sendJson(response, 200, { ok: true, database: 'SQLite' });
// Este grupo prepara ou valida as operações desta parte da API.
    if (resource === 'subjects' && request.method === 'GET' && parts.length === 2) return sendJson(response, 200, db.prepare(subjectSelect).all());
    if (resource === 'tasks' && request.method === 'GET' && parts.length === 2) return sendJson(response, 200, db.prepare(`${taskSelect} ORDER BY CASE t.status WHEN 'Pendente' THEN 0 WHEN 'Em andamento' THEN 1 ELSE 2 END, t.due_date`).all());
    // As leituras retornam listas prontas para exibição e incluem campos relacionados.
    if (resource === 'subjects' && request.method === 'POST' && parts.length === 2) {
      const subject = cleanSubject(await readJson(request));
      const result = db.prepare('INSERT INTO subjects (name, color) VALUES (?, ?)').run(subject.name, subject.color);
// Este grupo prepara ou valida as operações desta parte da API.
      return sendJson(response, 201, db.prepare(subjectById).get(Number(result.lastInsertRowid)));
    }
    if (resource === 'subjects' && request.method === 'PUT' && parts.length === 3) {
      const id = routeId(parts); const subject = cleanSubject(await readJson(request));
      if (!exists('subjects', id)) fail(404, 'Matéria não encontrada.');
// Este grupo prepara ou valida as operações desta parte da API.
      db.prepare('UPDATE subjects SET name = ?, color = ? WHERE id = ?').run(subject.name, subject.color, id);
      return sendJson(response, 200, db.prepare(subjectById).get(id));
    }
    // Criar e editar matéria usam instruções preparadas contra injeção SQL.
    if (resource === 'subjects' && request.method === 'DELETE' && parts.length === 3) {
      const id = routeId(parts); if (!exists('subjects', id)) fail(404, 'Matéria não encontrada.');
// Este grupo prepara ou valida as operações desta parte da API.
      db.prepare('DELETE FROM subjects WHERE id = ?').run(id);
      return sendJson(response, 200, { deleted: true });
    }
    if (resource === 'tasks' && request.method === 'POST' && parts.length === 2) {
      const task = cleanTask(await readJson(request));
// Este grupo prepara ou valida as operações desta parte da API.
      if (task.subject_id !== null && !exists('subjects', task.subject_id)) fail(400, 'A matéria escolhida não existe.');
      const result = db.prepare('INSERT INTO tasks (title, description, subject_id, due_date, priority, status) VALUES (?, ?, ?, ?, ?, ?)').run(task.title, task.description, task.subject_id, task.due_date, task.priority, task.status);
      return sendJson(response, 201, db.prepare(`${taskSelect} WHERE t.id = ?`).get(Number(result.lastInsertRowid)));
    }
    // A exclusão da matéria desvincula registros; a tarefa continua preservada.
    if (resource === 'tasks' && request.method === 'PUT' && parts.length === 3) {
// Este grupo prepara ou valida as operações desta parte da API.
      const id = routeId(parts); const task = cleanTask(await readJson(request));
      if (!exists('tasks', id)) fail(404, 'Tarefa não encontrada.');
      if (task.subject_id !== null && !exists('subjects', task.subject_id)) fail(400, 'A matéria escolhida não existe.');
      db.prepare('UPDATE tasks SET title = ?, description = ?, subject_id = ?, due_date = ?, priority = ?, status = ? WHERE id = ?').run(task.title, task.description, task.subject_id, task.due_date, task.priority, task.status, id);
      return sendJson(response, 200, db.prepare(`${taskSelect} WHERE t.id = ?`).get(id));
// Este grupo prepara ou valida as operações desta parte da API.
    }
    // A API confere existência e vínculo antes de atualizar uma tarefa.
    if (resource === 'tasks' && request.method === 'DELETE' && parts.length === 3) {
      const id = routeId(parts); if (!exists('tasks', id)) fail(404, 'Tarefa não encontrada.');
      db.prepare('DELETE FROM tasks WHERE id = ?').run(id);
      return sendJson(response, 200, { deleted: true });
// Este grupo prepara ou valida as operações desta parte da API.
    }
    fail(404, 'Rota não encontrada.');
  } catch (error) {
    const duplicate = String(error.message || '').includes('UNIQUE constraint failed');
    const status = error.status || (duplicate ? 409 : 500);
// Este grupo prepara ou valida as operações desta parte da API.
    const message = duplicate ? 'Já existe uma matéria com esse nome.' : (error.status ? error.message : 'Erro interno da API.');
    return sendJson(response, status, { message });
  }
  // Erros de entrada viram mensagens compreensíveis para a interface.
});
server.listen(port, '127.0.0.1', () => console.log(`EstudaFlow API disponível em http://localhost:${port}/api`));
// Este grupo prepara ou valida as operações desta parte da API.
// A API fica disponível apenas no computador local durante o desenvolvimento.

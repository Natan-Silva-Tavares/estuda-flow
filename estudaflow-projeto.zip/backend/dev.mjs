import { spawn } from 'node:child_process';
import process from 'node:process';
const healthUrl = 'http://127.0.0.1:3000/api/health';
const pause = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
// Este iniciador sobe a API antes da interface para evitar gravações sem conexão.
async function apiIsReady() {
  try { return (await fetch(healthUrl, { signal: AbortSignal.timeout(1000) })).ok; }
  catch { return false; }
}
// Uma API já iniciada pode ser reaproveitada sem criar outro servidor.
async function waitForApi() {
  for (let attempt = 0; attempt < 40; attempt += 1) {
    if (await apiIsReady()) return true;
    await pause(250);
// A verificação aguarda até dez segundos pela abertura do banco local.
  }
  return false;
}
let apiProcess = null;
let webProcess = null;
let stopping = false;
// As referências permitem encerrar somente os processos iniciados por este script.
if (!(await apiIsReady())) {
  apiProcess = spawn(process.execPath, ['--experimental-sqlite', 'backend/server.mjs'], { stdio: 'inherit' });
  apiProcess.on('error', (error) => { console.error('Não foi possível iniciar a API:', error.message); });
  if (!(await waitForApi())) {
    console.error('A API não iniciou. Confira se a porta 3000 está livre.');
    apiProcess.kill();
// Se o banco não responder, o iniciador para sem abrir uma interface incompleta.
    process.exit(1);
  }
} else {
  console.log('API já ativa; vou usar a conexão existente.');
}
// A interface só aparece depois que o serviço de dados responde.
webProcess = spawn(process.execPath, ['node_modules/@angular/cli/bin/ng.js', 'serve', '--proxy-config', 'proxy.conf.json', ...process.argv.slice(2)], { stdio: 'inherit' });
webProcess.on('error', (error) => { console.error('Não foi possível iniciar o Angular:', error.message); process.exitCode = 1; stopChildren(); });
// Os argumentos adicionais ainda permitem escolher outra porta para o Angular.
function stopChildren() {
  if (stopping) return;
  stopping = true;
  webProcess?.kill();
  apiProcess?.kill();
// Ctrl+C encerra os serviços iniciados nesta execução de forma coordenada.
}
process.on('SIGINT', stopChildren);
process.on('SIGTERM', stopChildren);
webProcess.on('exit', (code) => {
  if (!stopping) { stopping = true; apiProcess?.kill(); process.exitCode = code ?? 0; }
// Encerrar o Angular também desliga a API que este comando iniciou.
});
apiProcess?.on('exit', (code) => {
  if (!stopping) { stopping = true; webProcess?.kill(); process.exitCode = code ?? 1; }
// Se a API cair, a interface também é fechada para não parecer que salvou.
});

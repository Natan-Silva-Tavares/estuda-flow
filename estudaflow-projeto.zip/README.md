# EstudaFlow

Aplicação de organização de estudos feita em Angular com três rotas, interface Angular Material, dois CRUDs e uma API ligada a um banco SQLite local.

## O que está pronto

- **Visão geral** (`/`): resumo de tarefas, matérias e progresso.
- **Minhas tarefas** (`/tarefas`): criar, consultar, editar e excluir tarefas; cada tarefa tem matéria opcional, prazo, prioridade e status.
- **Matérias** (`/materias`): criar, consultar, editar e excluir matérias com cor de identificação.
- API REST em Node.js com persistência SQLite. O arquivo `backend/estudaflow.sqlite` é criado automaticamente e recebe alguns exemplos na primeira execução.
- Interface responsiva, componentes standalone, navegação Angular Router e proxy local entre front-end e API.

## Como iniciar

Requisito: Node.js 22.22.3+, 24.15+ ou 26+. O servidor usa apenas módulos nativos do Node e o banco SQLite incluído no Node.

1. Abra um terminal nesta pasta e instale as dependências do Angular:

   ```powershell
   npm install
   ```

2. Inicie a API, o banco e a interface juntos:

   ```powershell
   npm start
   ```

3. Acesse `http://localhost:4200` no navegador.

Pare os dois serviços com `Ctrl+C`. Se preferir executar só a API em um terminal separado, use `npm run api`. Para voltar aos dados de exemplo, pare o servidor e apague `backend/estudaflow.sqlite`; o banco será recriado na próxima inicialização.

## Como demonstrar o CRUD

1. Cadastre uma matéria em **Matérias** e escolha uma cor.
2. Crie uma tarefa e associe a matéria; confira se aparece na lista e no resumo inicial.
3. Edite o título ou mude o status para **Concluída** e veja o progresso se atualizar.
4. Exclua a tarefa e a matéria para demonstrar a operação de remoção.

## Organização do projeto

- `src/app/pages/`: telas da aplicação.
- `src/app/core/api.service.ts`: chamadas HTTP do Angular para os recursos.
- `src/app/core/models.ts`: tipos usados nas telas e nos formulários.
- `backend/server.mjs`: rotas REST, validação dos dados e acesso ao SQLite.
- `angular.json` e `tsconfig*.json`: configuração do Angular e do TypeScript.

Nos arquivos de código-fonte TypeScript, HTML, SCSS e JavaScript da API, cada grupo de cinco linhas é seguido por uma explicação em português. Os arquivos JSON de configuração não recebem comentários porque esse formato não permite comentários válidos.

## Ideia para apresentar

“O EstudaFlow ajuda a organizar tarefas de estudo. O Angular separa a navegação em três rotas, os formulários fazem os cadastros e o serviço envia as operações HTTP para uma API Node. A API valida os dados e os persiste em SQLite. As tarefas podem se relacionar com matérias, e o painel inicial usa esses dados para mostrar o progresso.”
